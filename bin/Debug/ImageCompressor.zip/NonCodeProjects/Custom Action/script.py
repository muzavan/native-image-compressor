import zipfile
import sys
import os

z = zipfile.ZipFile("package.zip","w")

for arg in sys.argv:
    z.write(arg)

z.close()
print("Done")